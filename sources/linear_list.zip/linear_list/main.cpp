#include <iostream>
// c++顺序表实现
using namespace std;

class List {
public:
    explicit List(int size);                        //初始化顺序表
    void Create_List(int a[],int n);                //由a数组中的元素建造顺序表
    void Destroy_List();                            //销毁顺序表
    bool List_Empty();                              //判空
    bool List_Full();                               //判满
    int List_Length();                              //返回长度
    int List_Search(int Element);                   //查找元素位置
    bool List_Insert(int i, int Element);           //插入元素
    bool Delete_Elem(int i);                        //删除元素
    void List_Traverse();                           //遍历顺序表
    int Get_Elem(int i);                            //获取i的元素

private:
    int *data; // 存放顺序表中的元素
    int m_Size;
    int m_Length;
};

class List;
List::List(int size) {
    m_Size = size;
    data = new int[m_Size];
    m_Length = 0;
}

void List::Create_List(int *a, int n) {
    int i;
    for(i=0;i<n;i++)
        data[i] = a[i];
    m_Length = i;
}

void List::Destroy_List() {
    delete[]data;
}

bool List::List_Empty() {
    return m_Length == 0;
}

bool List::List_Full() {
    return m_Length == m_Size;
}

int List::List_Length() {
    return m_Length;
}

int List::List_Search(int Element) {
    for (int i = 0; i < m_Length; i++) {
        if (Element == data[i])
            return i;
    }
    return -1;
}

int List::Get_Elem(int i){
    return data[i];
}

bool List::List_Insert(int i, int Element) {
    if (i < 0 || List_Full() || i > m_Length)
        return false;
    else {
        for (int j = m_Length; j >= i; j--)
            data[j] = data[j-1];
        data[i-1] = Element;
        m_Length++;
        return true;
    }
}

bool List::Delete_Elem(int i) {
    if (i < 0 || i > m_Length)
        return false;
    else {
        for (int j=i; j<m_Length; j++)
            data[j-1] = data[j];
    }
    m_Length--;
    return true;
}

void List::List_Traverse() {
    for (int i = 0; i < m_Length; i++)
        cout << data[i] << endl;
}

int main() {
    auto *list = new List(5);
    int arr[3] = {3,4,5};
    list->Create_List(arr,3);
    list->List_Insert(2,1);
    cout << "length:" << list->List_Length() << endl;
    list->Delete_Elem(6);
    list->List_Traverse();
    cout << "Is_Empty ? " << list->List_Empty() << endl;
    cout << "Is_Full ? " << list->List_Full() << endl;
    cout << "data: " << list->Get_Elem(1) << endl;
    cout << "i: " << list->List_Search(5) << endl;
    list->Destroy_List();
    //list->List_Traverse();
    return 0;
}