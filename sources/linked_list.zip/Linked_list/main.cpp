#include <iostream>
#include "List.h"
using namespace std;

int main() {
    
    auto *list=new List();

    Node n1(9);
    Node n2(1);
    Node n3(3);
    Node n4(5);

    cout << "Length:" << list->List_Length() <<endl;
    list->List_Insert_Head(&n1);
    list->List_Insert_Head(&n2);
    list->List_Insert(0,&n3);
    list->List_Insert_Tail(&n4);

    list->List_Traverse();
    cout <<endl;
    cout << "Length:" << list->List_Length() <<endl;

    list->List_GetElem(2,&n2);
    cout << "n2:"<<n2.Data <<endl;

    list->List_PriorElem(2,&n2);
    cout << "n2:"<<n2.Data <<endl;

    list->List_NextElem(2,&n2);
    cout << "n2:"<<n2.Data <<endl;

    cout << "n4 seat:" <<list->List_Search(&n4) <<endl;

    list->List_Delete(&n4);

    list->List_Traverse();
    cout << endl;
    delete list;
    return 0;
}