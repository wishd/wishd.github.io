#include "List.h"
#include <iostream>
using namespace std;

List::List(void)
{
    p_Head = new Node();
    if ( NULL == p_Head)
    {
        cout << "Memory failed!" << endl;
        exit(0);
    }
    p_Head->p_Next=NULL;
    m_iLength =0;
}

void List::Clear_List()
{
    Node *tempNode = p_Head->p_Next;
    Node *newNode = p_Head->p_Next;
    while ( NULL != tempNode)
    {
        newNode = tempNode->p_Next;
        delete tempNode;
        tempNode = newNode;
    }

    p_Head->p_Next=NULL;
    m_iLength=0;
}

List::~List(void)
{
    Clear_List();
    delete p_Head;
    p_Head=NULL;
}

bool List::List_Empty()
{
    if ( 0 == m_iLength )
    {
        return true;
    }
    else
        return false;

}

int List::List_Length()
{
    return m_iLength;
}

bool List::List_GetElem(int seat,Node *Elem)
{
    if (seat >= m_iLength || seat<0)
        return false;
    Node *tempNode = p_Head;

    for (int i=0;i<=seat;i++)
    {
        tempNode = tempNode->p_Next;
    }

    Elem->Data=tempNode->Data;

    return true;



}

int List::List_Search(Node *Elem)
{
    Node *tempNode = p_Head->p_Next;
    int count=0;
    while ( NULL != tempNode)
    {
        if ( Elem->Data==tempNode->Data)
        {
            return count;
        }

        tempNode = tempNode->p_Next;
        count++;
    }

    return -1;
}

bool List::List_Insert_Head(Node *Elem)
{
    //Node *tempNode =p_Head->p_Next;
    Node *NewNode = new Node();
    if ( NULL == NewNode)
        return false;
    NewNode->Data = Elem->Data;

    NewNode->p_Next = p_Head->p_Next;
    p_Head->p_Next = NewNode;
    m_iLength++;
    return true;
}

bool List::List_Insert_Tail(Node *Elem)
{
    Node *tempNode = p_Head;
    Node *NewNode = new Node();
    if ( NULL == NewNode)
        return false;
    NewNode->Data = Elem->Data;
    while ( NULL != tempNode->p_Next)
    {
        tempNode = tempNode->p_Next;
    }

    tempNode->p_Next = NewNode;
    NewNode->p_Next=NULL;
    m_iLength++;
    return true;
}
bool List::List_Insert(int seat,Node *Elem)
{
    if (seat>=m_iLength || 0>seat)
        return false;

    Node *NewNode = new Node();
    if ( NULL == NewNode )
        return false;
    NewNode->Data=Elem->Data;

    Node *tempNode = p_Head;
    for (int i=0;i<seat;i++)
    {
        tempNode=tempNode->p_Next;
    }

    NewNode->p_Next=tempNode->p_Next;
    tempNode->p_Next=NewNode;
    m_iLength++;
    return true;


}

bool List::List_Delete(Node *Elem)
{
    Node *tempNode = p_Head->p_Next;
    Node *priorNode = p_Head;

    while ( NULL != tempNode)
    {
        if (tempNode->Data == Elem->Data)
        {
            priorNode->p_Next=tempNode->p_Next;
            delete tempNode;
            tempNode=NULL;
            m_iLength--;
            return true;
        }
        priorNode=tempNode;
        tempNode=tempNode->p_Next;
    }

    return false;
}

bool List::List_PriorElem(int seat,Node *Elem)
{

    if ( 0 >= seat || seat>=m_iLength)
        return false;

    Node *tempNode = p_Head;

    for (int i=0;i<seat;i++)
    {
        tempNode=tempNode->p_Next;
    }
    Elem->Data=tempNode->Data;
    return true;
}

bool List::List_NextElem(int seat,Node *Elem)
{
    if ( 0 > seat || seat>=m_iLength-1)
        return false;

    Node *tempNode = p_Head->p_Next;

    for (int i=0;i<seat;i++)
    {
        tempNode=tempNode->p_Next;
    }
    Elem->Data=tempNode->p_Next->Data;
    return true;

}

void List::List_Traverse()
{
    Node *tempNode = p_Head->p_Next;

    while(NULL != tempNode)
    {
        cout << tempNode->Data << "-->" ;
        tempNode=tempNode->p_Next;
    }
}