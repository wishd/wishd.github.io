#include "Node.h"

Node::Node(int data)
{
    Data=data;
}