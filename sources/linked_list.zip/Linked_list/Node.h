#ifndef LINKED_LIST_NODE_H
#define LINKED_LIST_NODE_H

class Node
{
public:
    Node(int data=0);
    int Data;
    Node *p_Next;
};

#endif //LINKED_LIST_NODE_H
