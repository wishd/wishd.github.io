#ifndef LINKED_LIST_LIST_H
#define LINKED_LIST_LIST_H

#include "Node.h"
class List
{
public:
    List(void);										//构造函数
    ~List(void);									//析构函数
    void Clear_List();								//清空该链表
    bool List_Empty();								//判断链表是否为空
    int List_Length();								//返回链表当前长度
    bool List_GetElem(int seat,Node *Elem);			//获取seat位置处元素的数据
    int List_Search(Node *Elem);					//查找第一个与Elem数据相同元素的位置，未找到返回-1
    bool List_Insert_Head(Node *Elem);				//在链表头插入一个结点
    bool List_Insert_Tail(Node *Elem);				//在链表尾插入一个节点
    bool List_Insert(int seat,Node *Elem);			//在seat位置插入一个节点
    bool List_Delete(Node *Elem);					//删除第一个与Elem数据相同的节点
    bool List_PriorElem(int seat,Node *Elem);		//获得seat处的前驱给Elem
    bool List_NextElem(int seat,Node *Elem);		//获得seat处的后继给Elem
    void List_Traverse();							//遍历链表

private :
    int m_iLength;									//链表当前长度
    Node *p_Head;									//头结点
};

#endif //LINKED_LIST_LIST_H
