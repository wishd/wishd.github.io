#ifndef STACK_MYSTACK_H
#define STACK_MYSTACK_H

class MyStack
{
public:
    explicit MyStack(int size);             //初始化栈
    void Destroy_MyStack();                 //清除栈
    bool Stack_Empty();                     //判空
    bool Stack_Full();                      //判满
    void Clear_Stack();                     //清空栈
    int Stack_Length();                     //返回长度
    bool Push(int elem);                    //push
    bool Pop(int &elem);                    //pop
    void Stack_Traverse(bool Button);       //遍历栈
    int Get_Top(int &elem);                 //获取栈顶元素

private:
    int *m_pBuffer;
    int m_Size;
    int m_Top;
};

#endif //STACK_MYSTACK_H
