#include "MyStack.h"
#include <iostream>
using namespace std;

MyStack::MyStack(int size) {
    m_Size = size;
    m_pBuffer = new int[m_Size];
    m_Top = 0;
}

void MyStack::Destroy_MyStack() {
    delete []m_pBuffer;
}

bool MyStack::Stack_Empty() {
    return !m_Top;
}

bool MyStack::Stack_Full() {
    return (m_Top == m_Size) != 0;
    // return (m_Top == m_Size) ? true : false;
}

void MyStack::Clear_Stack() {
    m_Top = 0;
}

int MyStack::Stack_Length() {
    return m_Top;
}

bool MyStack::Push(int elem) {
    if(Stack_Full()){
        return false;
    }
    else{
        m_pBuffer[m_Top] = elem;
        m_Top++;
        return true;
    }
}

bool MyStack::Pop(int &elem) {
    if(Stack_Empty()){
        return false;
    }
    else{
        m_Top--;
        elem = m_pBuffer[m_Top];
        return true;
    }
}

void MyStack::Stack_Traverse(bool Button) {
    if(Button)
    {
        for (int i= 0; i < m_Top; i++) {
            cout << m_pBuffer[i] << endl;
        }
    }
    else
    {
        for (int i = m_Top-1; i >=0 ; i--) {
            cout << m_pBuffer[i] << endl;
        }
    }

}

int MyStack::Get_Top(int &elem) {
    elem = m_pBuffer[m_Top-1];
    return elem;
}


