#include <iostream>
#include "MyStack.h"
using namespace std;
#define B 2
#define O 8
#define H 16

// 10进制转化2进制
int DtoB(int N) {
    cout << "转化的数: " << N << endl;
    auto *p = new MyStack(32);
    // 转换的数N
    int mod = 0;
    // 短除法
    while (N !=0){
        mod = N % B;
        p->Push(mod);
        N = N / B;
    }
    p->Stack_Traverse(false);
    return 0;
}

// 测试函数工作
int test(){

    cout << "-----测试函数开始-----" << endl;
    // 初始化操作
    auto *pStack = new MyStack(3);

    //栈判空
    if(pStack->Stack_Empty()){
        cout << "栈空" << endl;
    }

    // 入栈
    pStack->Push(1);
    pStack->Push(2);
    pStack->Push(3);

    //遍历栈
    pStack->Stack_Traverse(false);

    //栈判满
    if(pStack->Stack_Full()){
        cout << "栈满" << endl;
    }

    // 取栈顶元素
    int top = 0;
    cout << "栈顶元素: " << pStack->Get_Top(top) << endl;

    //出栈
    int elem = 0;
    pStack->Pop(elem);
    pStack->Stack_Traverse(false);

    // 取栈顶元素
    cout << "栈顶元素: " << pStack->Get_Top(top) << endl;

    //栈判空
    if(pStack->Stack_Empty()){
        cout << "栈空" << endl;
    }
}

int main() {

    test();
    cout << "-----我是分割线-----" <<endl;
    DtoB(198);
    cout << "-----我是分割线-----" <<endl;
    DtoB(2005);
    cout << "-----我是分割线-----" <<endl;
    DtoB(10);
    return 0;
}
